-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Apr 27, 2025 at 06:47 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `healthy_habitat_network`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `admin_name` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `admin_name`, `email`, `password`) VALUES
(1, 'Admin User', 'admin@example.com', 'adminpassword');

-- --------------------------------------------------------

--
-- Table structure for table `areas`
--

CREATE TABLE `areas` (
  `id` int(11) NOT NULL,
  `location_name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `areas`
--

INSERT INTO `areas` (`id`, `location_name`) VALUES
(1, ''),
(2, ''),
(3, '');

-- --------------------------------------------------------

--
-- Table structure for table `businesses`
--

CREATE TABLE `businesses` (
  `id` int(11) NOT NULL,
  `business_name` varchar(255) NOT NULL,
  `contact_info` varchar(255) DEFAULT NULL,
  `product_service` varchar(255) NOT NULL,
  `price_range` enum('Affordable','Moderate','Premium') DEFAULT NULL,
  `certifications` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `businesses`
--

INSERT INTO `businesses` (`id`, `business_name`, `contact_info`, `product_service`, `price_range`, `certifications`) VALUES
(1, 'Healthy Eats', '123 Healthy St.', 'Organic Meal Delivery', 'Affordable', 'USDA Organic'),
(2, 'Green Fitness', '456 Fitness Ave.', 'Yoga and Meditation Classes', 'Moderate', 'Non-GMO'),
(3, 'Eco Clean', '789 Green Rd.', 'Eco-Friendly Home Cleaning', 'Premium', 'Certified Green');

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `name`) VALUES
(1, 'Fitness'),
(2, 'Nutrition'),
(3, 'Wellness');

-- --------------------------------------------------------

--
-- Table structure for table `locations`
--

CREATE TABLE `locations` (
  `id` int(11) NOT NULL,
  `location_name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `locations`
--

INSERT INTO `locations` (`id`, `location_name`) VALUES
(28, 'London'),
(29, 'Manchester'),
(30, 'Birmingham'),
(31, 'Luton'),
(32, 'Eastham'),
(33, 'Wembly'),
(34, 'Totenam');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(11) NOT NULL,
  `description` text DEFAULT NULL,
  `price` decimal(10,2) DEFAULT NULL,
  `health_benefits` text DEFAULT NULL,
  `category` varchar(100) DEFAULT NULL,
  `business_id` int(11) DEFAULT NULL,
  `available` tinyint(1) NOT NULL DEFAULT 1,
  `category_id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `certification` varchar(100) DEFAULT NULL,
  `location_id` int(11) NOT NULL,
  `area_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `description`, `price`, `health_benefits`, `category`, `business_id`, `available`, `category_id`, `name`, `certification`, `location_id`, `area_id`) VALUES
(1, 'Eco-friendly yoga mat made from sustainable cork.', 45.99, 'Improves posture, eco-friendly.', 'Fitness Gear', 2, 1, 0, '', NULL, 0, 0),
(2, 'Reusable, organic cotton face mask.', 15.99, 'Helps reduce skin irritation and pollution exposure.', 'Reusable Health Products', 3, 1, 0, '', NULL, 0, 0),
(3, 'A nutritious green smoothie packed with vitamins.', 5.99, 'Boosts energy, detoxifies the body.', 'Organic Foods', 1, 1, 0, '', NULL, 0, 0),
(7, 'Apple', 160.00, NULL, NULL, 3, 1, 1, 'Apple123', 'Good', 0, 0),
(8, 'Test', 290.00, NULL, NULL, 3, 1, 1, 'Demo1', 'Test', 0, 0),
(9, 'Habbit', 300.00, NULL, NULL, 3, 1, 1, 'Koco', 'Good', 0, 0),
(10, 'uubvv', 120.00, NULL, NULL, 3, 1, 2, 'shampoo', 'Good', 0, 0),
(11, '123', NULL, NULL, NULL, NULL, 1, 6, 'Zoo', NULL, 0, 0),
(12, 'Busquits', 300.00, NULL, NULL, 3, 1, 2, 'Treat', 'Test', 25, 0),
(13, 'qw', 1234.00, NULL, NULL, 3, 1, 1, 'Koco1', '', 1, 0),
(14, 'Haisty', 123.00, NULL, NULL, 3, 1, 1, 'Apples', 'Goods', 29, NULL),
(15, 'Happy', 250.00, NULL, NULL, 3, 1, 2, 'Cocunut', 'Test', 29, NULL),
(16, 'test', 300.00, NULL, NULL, 3, 1, 1, 'Koco', 'Test', 28, NULL),
(22, 'test', 123.00, NULL, NULL, 3, 1, 2, 'Helloq', 'Goods', 28, NULL),
(26, 'test', 123.00, NULL, NULL, 19, 1, 2, 'Kocoq', 'Good', 28, NULL),
(27, 'test', 123.00, NULL, NULL, 19, 1, 2, 'Kocoq', 'Good', 28, NULL),
(28, 'test', 123.00, NULL, NULL, 19, 1, 1, 'nbhqww', 'Test', 29, NULL),
(29, 'demo', 300.00, NULL, NULL, 20, 1, 1, 'Demo', 'Good', 28, NULL),
(30, 'tes', 500.00, NULL, NULL, 3, 1, 3, 'test', 'Good', 31, NULL),
(31, 'test', 300.00, NULL, NULL, 3, 1, 1, 'Sample', 'Good', 29, NULL),
(32, 'test', 120.00, NULL, NULL, 3, 1, 2, 'Koconut', 'Good', 29, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `residents`
--

CREATE TABLE `residents` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `location` int(11) DEFAULT NULL,
  `age_group` varchar(50) DEFAULT NULL,
  `gender` varchar(10) DEFAULT NULL,
  `interests` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `residents`
--

INSERT INTO `residents` (`id`, `name`, `email`, `password`, `location`, `age_group`, `gender`, `interests`) VALUES
(1, 'John Doe', 'john@example.com', 'password123', 1, '25-35', 'Male', 'Fitness, Nutrition'),
(2, 'Jane Smith', 'jane@example.com', 'password123', 2, '35-45', 'Female', 'Mental Health, Sustainable Living'),
(3, 'Samuel Brown', 'samuel@example.com', 'password123', 3, '45-55', 'Male', 'Fitness, Mental Health');

-- --------------------------------------------------------

--
-- Table structure for table `title`
--

CREATE TABLE `title` (
  `id` int(11) NOT NULL,
  `title_name` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `title`
--

INSERT INTO `title` (`id`, `title_name`) VALUES
(1, 'Mr'),
(2, 'Miss'),
(3, 'Mrs'),
(4, 'Dr');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` enum('resident','business','admin','council') NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `email`, `password`, `role`, `created_at`) VALUES
(1, 'Resident', 'resident@gmail.com', '$2y$10$3g1.pwvViz32.s56ZG43GO34U80PB4KMwBcRwfhxjYMw3suPpra9O', 'resident', '2025-04-24 20:29:10'),
(2, 'testuser', 'test@example.com', '$2y$10$/oq2bi0LbFMpOVtbQqI5m..pvkqXtigoAC4YtN88RzjNTKorBhtty', 'resident', '2025-04-24 20:31:03'),
(3, 'Business', 'business@gmail.com', '$2y$10$zi/c/J4ZBnPUcBYIEoBEhexPJqvL.Mk6cWBUk3.B9gCrmVb3LhtNO', 'business', '2025-04-24 21:01:09'),
(5, 'Business1', 'business1@gmail.com', '$2y$10$vRb0eNAQbpq4y3sd.DK5R.lUUbdnPouQqUFMAoEr6FBxT7mNrMYGy', 'business', '2025-04-24 23:11:36'),
(6, 'Resident1', 'resident1@gmail.com', '$2y$10$VysKYw5HdoF4JDVGbAZhkOfGnnVnMaj3wM2TorvceOIXOR8eM3.JK', 'resident', '2025-04-24 23:36:05'),
(7, 'AdminTest', 'admintest@gmail.com', '$2y$10$UHY0oVIbLadkouZumBAboO9cb40rKx0FlHWT5Zb9wz4TkjBlCLtG6', 'admin', '2025-04-25 11:30:58'),
(8, 'Resident3', 'resident3@gmail.com', '$2y$10$X6rEvzcVjyLhJfAEUgOLm.oSR8WsIGEgO5T9gUPizOZcIHdTeUf6i', 'resident', '2025-04-25 11:49:26'),
(9, 'Admin', 'admin@gmail.com', '$2y$10$sZCCvcQyrNES9Z31jibiI.BjawOMNywf2l.YCUh6KDWPTja0uY4IO', 'admin', '2025-04-25 11:51:43'),
(11, 'Resident2', 'res@gmail.com', '$2y$10$pV2w10UqgaC74WhC8i4CEOp4ntoGBOPqHsn0jLqpBFDrF3lhgpKPG', 'resident', '2025-04-26 12:00:12'),
(15, 'Business2', 'bus@gmail.com', '$2y$10$2jLKlUef4yf0NGieOicjful8V3FG4I2DrWtllsm1N6mtlz42rsrUK', 'business', '2025-04-26 12:03:17'),
(18, 'Admin2', 'adm@gmail.com', '$2y$10$.2h5CS8ocy6iPtyPNUVoM.wO5onvHcywjZw1CJTKTJAIbNHwO2MkC', 'admin', '2025-04-26 12:06:52'),
(19, 'BusinessTest', 'b@gmail.com', '$2y$10$O6jXKfH811ygvGVUOxXjIe6irMB0YtiqQIAdpeaEqKAbXHMrRDM5S', 'business', '2025-04-26 12:31:50'),
(20, 'DemoBusiness', 'demobusiness@gmail.com', '$2y$10$iPaGcpuQvmBO536DMFxNg.cxV5f4mSPjI5nAPHnvDg46g8fBK24SO', 'business', '2025-04-26 12:46:44'),
(21, 'DemoResident', 'demoresident@gmail.com', '$2y$10$zUD8eHVjuNRb3vIyrk0BsOTWyUr93zM6/c5j60Ca9pItjH.B6gjfu', 'resident', '2025-04-26 12:47:38'),
(22, 'DemoAdmin', 'demoadmin@gmail.com', '$2y$10$.tYqIsp./YMcgNdyG1CSQO/udr/JRDxg3JsfhG1TtY.jvb7QghJ52', 'admin', '2025-04-26 12:48:26');

-- --------------------------------------------------------

--
-- Table structure for table `votes`
--

CREATE TABLE `votes` (
  `id` int(11) NOT NULL,
  `resident_id` int(11) DEFAULT NULL,
  `product_id` int(11) DEFAULT NULL,
  `vote_value` enum('Yes','No') DEFAULT NULL,
  `vote_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `vote` enum('yes','no') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `votes`
--

INSERT INTO `votes` (`id`, `resident_id`, `product_id`, `vote_value`, `vote_date`, `vote`) VALUES
(1, 1, 1, 'Yes', '2025-04-23 16:08:49', 'yes'),
(2, 2, 2, 'No', '2025-04-23 16:08:49', 'yes'),
(3, 3, 3, 'Yes', '2025-04-23 16:08:49', 'yes'),
(7, 1, 7, NULL, '2025-04-24 23:35:18', 'yes'),
(10, 8, 7, NULL, '2025-04-25 11:50:33', 'yes'),
(11, 8, 8, NULL, '2025-04-25 11:50:35', 'yes'),
(12, 8, 10, NULL, '2025-04-25 11:50:52', 'no'),
(13, 1, 14, NULL, '2025-04-26 00:40:04', 'yes'),
(14, 1, 15, NULL, '2025-04-26 01:48:12', 'yes'),
(15, 1, 16, NULL, '2025-04-26 17:26:48', 'yes'),
(16, 1, 28, NULL, '2025-04-26 17:26:49', 'yes');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `areas`
--
ALTER TABLE `areas`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `businesses`
--
ALTER TABLE `businesses`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `locations`
--
ALTER TABLE `locations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_products_business_id` (`business_id`);

--
-- Indexes for table `residents`
--
ALTER TABLE `residents`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`),
  ADD KEY `location` (`location`);

--
-- Indexes for table `title`
--
ALTER TABLE `title`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `votes`
--
ALTER TABLE `votes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `product_id` (`product_id`),
  ADD KEY `votes_ibfk_1` (`resident_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `areas`
--
ALTER TABLE `areas`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `businesses`
--
ALTER TABLE `businesses`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `locations`
--
ALTER TABLE `locations`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=35;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;

--
-- AUTO_INCREMENT for table `residents`
--
ALTER TABLE `residents`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `title`
--
ALTER TABLE `title`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `votes`
--
ALTER TABLE `votes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `products`
--
ALTER TABLE `products`
  ADD CONSTRAINT `fk_products_business_id` FOREIGN KEY (`business_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `residents`
--
ALTER TABLE `residents`
  ADD CONSTRAINT `residents_ibfk_1` FOREIGN KEY (`location`) REFERENCES `areas` (`id`);

--
-- Constraints for table `votes`
--
ALTER TABLE `votes`
  ADD CONSTRAINT `votes_ibfk_1` FOREIGN KEY (`resident_id`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `votes_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
